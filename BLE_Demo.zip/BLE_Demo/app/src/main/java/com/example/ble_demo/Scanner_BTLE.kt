package com.example.ble_demo

import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat.getSystemService


class Scanner_BTLE(mainActivity: MainActivity, scanPeriod: Long, signalStrength: Int) {

    private val ma = mainActivity
    private val sp = scanPeriod
    private val ss = signalStrength

    private var bluetoothManager: BluetoothManager? = ma.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private var bluetoothAdapter: BluetoothAdapter = bluetoothManager!!.adapter
    private lateinit var mLeScanCallBack : BluetoothAdapter.LeScanCallback
    var bleScanCallBack :ScanCallback = object : ScanCallback(){
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            super.onScanResult(callbackType, result)
            var device = result?.device
            if(device!=null){
                val uuid : String = device.uuids.toString()
                Log.v("DeviceListActivity","onScanResult: ${device.address} - ${device.name} - ${device.uuids}")
                ma.addDevice(device,result!!.rssi)
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            super.onBatchScanResults(results)
            Log.d("DeviceListActivity","onBatchScanResults:${results.toString()}")
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Log.d("DeviceListActivity", "onScanFailed: $errorCode")
        }
    }
    private val gattCallback = object : BluetoothGattCallback(){
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            super.onConnectionStateChange(gatt, status, newState)
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            super.onServicesDiscovered(gatt, status)
        }

        override fun onCharacteristicRead(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            status: Int
        ) {
            super.onCharacteristicRead(gatt, characteristic, status)
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            status: Int
        ) {
            super.onCharacteristicWrite(gatt, characteristic, status)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?
        ) {
            super.onCharacteristicChanged(gatt, characteristic)
        }

    }

    private var mScanning: Boolean = false

    private var utils = Utils()
    var hand = Handler(Looper.getMainLooper())

    fun isScanning() : Boolean {
        return mScanning
    }
    fun start(){
        mLeScanCallBack =
        BluetoothAdapter.LeScanCallback { bluetoothDevice, rssi, bytes ->
            val new_rssi = rssi
            if(rssi>ss){
                hand.post {
                    ma.addDevice(bluetoothDevice, new_rssi)
                }
            }
    }
        if(!utils.checkBluetooth(bluetoothAdapter)){
            utils.requestBluetoohactivity(ma)
            ma.stopScan()
        }else{
            scanLeDevices(true)
        }
    }

    fun stop(){
         scanLeDevices(false)
    }

    fun scanLeDevices(request : Boolean){
        if(request && !mScanning){
            utils.toast(ma.applicationContext, "Starting BLE Scan")
            hand.postDelayed({
                utils.toast(ma,"Stoping BLE Scan...")
                 mScanning = false
                bluetoothAdapter.bluetoothLeScanner.stopScan(bleScanCallBack)


                ma.stopScan()
            },sp)
            mScanning = true;
            bluetoothAdapter.bluetoothLeScanner.startScan(bleScanCallBack)
        }else{
            utils.toast(ma.applicationContext, "Stoping BLE Scan")
        }
    }
}