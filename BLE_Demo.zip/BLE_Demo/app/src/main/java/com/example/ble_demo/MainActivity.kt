package com.example.ble_demo

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanSettings
import android.content.ContentValues
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.android.synthetic.main.activity_main.*
import java.util.ArrayList

class MainActivity : AppCompatActivity(), View.OnClickListener, AdapterView.OnItemClickListener{

    private val REQUEST_ENABLE_BT = 1
    private lateinit var mBTDevicehashMap : HashMap<String, BTLE_Device>
    private lateinit var mBTDeviceArrayList : ArrayList<BTLE_Device>
    private lateinit var adapter: ListAdapter_BTLE_Devices
    private lateinit var broadcastreceiverBtstate: BroadcastReceiver_BTState
    lateinit var utils : Utils
    private lateinit var mbtleScammer : Scanner_BTLE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        utils = Utils();
        if(!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){

            utils.toast(getApplicationContext(), "BLE not supported");
            finish();
        }

        broadcastreceiverBtstate = BroadcastReceiver_BTState(applicationContext)
        mbtleScammer = Scanner_BTLE(this,15000,-75)
        mBTDevicehashMap =  HashMap();
        mBTDeviceArrayList = ArrayList();

        adapter = ListAdapter_BTLE_Devices(this,R.layout.btle_device_list_item,mBTDeviceArrayList)

        var listView = ListView(this)
        listView.adapter = adapter
        listView.setOnItemClickListener(this)
        scrollView.addView(listView)
        btn_scan.setOnClickListener(this)

    }

    override fun onStart() {
        super.onStart()
        registerReceiver(broadcastreceiverBtstate, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(broadcastreceiverBtstate)
        stopScan()
    }

    override fun onPause() {
        super.onPause()
        stopScan()
    }

    override fun onClick(v: View?) {

        if (v != null) {
            when(v.id){
                btn_scan.id -> {
                    if (!mbtleScammer.isScanning()) startScan()
                    else stopScan()

                }
                }

            }
        }


    override fun onItemClick(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        TODO("Not yet implemented")
    }

    fun startScan(){
        btn_scan.text = "Scanning..."

        mBTDeviceArrayList.clear()
        mBTDevicehashMap.clear()

        adapter.notifyDataSetChanged()

        mbtleScammer.start()
    }
    fun stopScan(){
        btn_scan.text = "Scan Again"
        mbtleScammer.stop()
    }

    fun addDevice(device: BluetoothDevice, rssi : Int){
        val address = device.address

        if(!mBTDevicehashMap.containsKey(address)){
            var btleDevice = BTLE_Device(device)
             btleDevice.setRSSI(rssi)


            mBTDevicehashMap.put(address,btleDevice)
            mBTDeviceArrayList.add(btleDevice)
        }else{
            mBTDevicehashMap.get(address)!!.setRSSI(rssi)
        }
        adapter.notifyDataSetChanged()
    }
}
